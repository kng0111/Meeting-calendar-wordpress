# Contributors

This experiment is built by many contributors and volunteers. Thanks to all of them for their work!

This list is manually curated to include valuable contributions by volunteers that do not include code, such as user testing, providing feedback, or mockups. Please edit this list to include new contributors as they come in. There is no particular order to this list. If you or someone else was omitted from this list, we assure you that was not intentional. 
Please let us know and we'll add you. 

| GitHub Username | WordPress.org Username|
| --------------- | --------------------- |
| @kjellr | @kjellr |
| @karmatosed | @karmatosed |
| @mapk | @mapk |
| @azaozz | @azaozz |
| @draganescu | @andraganescu |
| @melchoyce | @melchoyce |
| @sarahmonster | @tinkerbelly |
| @akkspros | @passoniate |
