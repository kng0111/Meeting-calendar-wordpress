# Data Validation

This content has been moved to the [Data Validation page](https://developer.wordpress.org/apis/security/data-validation/) in the Common APIs Handbook.